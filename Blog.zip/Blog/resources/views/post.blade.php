<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    {{-- bootstrap --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <form action="{{ route('post.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class=" col-6">
                <textarea name="tone" id="" cols="30" rows="10"></textarea>
            </div>
            <div class=" col-6">
                <input type="file" name="ione" id="" class=" m-5">
            </div>
        </div>

        <div class="row">
            <div class=" col-6">
                <textarea name="ttwo" id="" cols="30" rows="10"></textarea>
            </div>
            <div class=" col-6">
                <input type="file" name="itwo" id="" class=" m-5">
            </div>
        </div>

        <div class="row">
            <div class=" col-6">
                <textarea name="tthree" id="" cols="30" rows="10"></textarea>
            </div>
            <div class=" col-6">
                <input type="file" name="ithree" id="" class=" m-5">
            </div>
        </div>
        <input type="text" name="format" value="{{ $data['format'] ?? '' }}">
        <input type="submit" value="Post">
    </form>
</body>

</html>
