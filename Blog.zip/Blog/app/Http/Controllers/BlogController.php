<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{
    public function index()
    {
        return view('format');
    }

    public function format(Request $request)
    {
        $data = [
            'format' => $request->format,
        ];
        return redirect('/post')->with('data', $data);
    }

    public function post()
    {
        $data = session('data');
        return view('post', compact('data'));
    }

    public function store(Request $request)
    {
        $img = ['ione', 'itwo', 'ithree'];
        $fname = [];
        foreach ($img as $item) {
            $file = $request->file($item);
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            $file->move(public_path() . '/imgData', $file_name);
            $fname[$item] = $file_name;
        }
        $data = [
            'textOne' => $request->tone,
            'textTwo' => $request->ttwo,
            'textThree' => $request->tthree,
            'imgOne' => $fname['ione'],
            'imgTwo' => $fname['itwo'],
            'imgThree' => $fname['ithree'],
            'format' => $request->format,
        ];
        Post::create($data);
        return redirect('/');
    }

    public function blog()
    {
        $post = Post::all();
        return view('blog', compact('post'));
    }

    public function details($id)
    {
        $data = DB::table('posts')
            ->where('id', $id)
            ->first();
        $view = $data->format;
        return view($view, compact('data'));
    }
}
