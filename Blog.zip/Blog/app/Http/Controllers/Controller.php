<?php

namespace App\Http\Controllers;

use GuzzleHttp\Psr7\Request;

abstract class Controller
{
    //
}
