<?php

use App\Http\Controllers\BlogController;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Route;

Route::get('/', [BlogController::class, 'index'])->name('index');
Route::get('/format', [BlogController::class, 'format'])->name('format');
Route::get('/post', [BlogController::class, 'post'])->name('post');
Route::post('/post', [BlogController::class, 'store'])->name('post.store');
Route::get('/blog', [BlogController::class, 'blog'])->name('blog');
Route::get('/details, {id}', [BlogController::class, 'details'])->name('details');
